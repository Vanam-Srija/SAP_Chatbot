sap.ui.define([
    "sap/ui/core/mvc/Controller"
], (Controller) => {
    "use strict";

    return Controller.extend("sap.chatbot.project1.controller.Main", {
        onInit() {
        }
    });
});